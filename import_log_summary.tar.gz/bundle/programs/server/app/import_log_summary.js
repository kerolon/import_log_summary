(function(){

/////////////////////////////////////////////////////////////////////////
//                                                                     //
// import_log_summary.js                                               //
//                                                                     //
/////////////////////////////////////////////////////////////////////////
                                                                       //
var Logs = new Mongo.Collection("logs");                               // 1
var Comments = new Mongo.Collection("comments");                       // 2
                                                                       //
if (Meteor.isClient) {                                                 // 4
    $(window).load(function () {                                       // 5
        $('#chat-area')[0].style.display = 'none';                     // 6
        var publicSetting = Meteor.settings["public"];                 // 7
        if (publicSetting.app_title) {                                 // 8
            $("#app_title").html(publicSetting.app_title);             // 9
        }                                                              //
        if (publicSetting.tab1_title) {                                // 11
            $("#tab1_title").html(publicSetting.tab1_title);           // 12
        }                                                              //
        if (publicSetting.tab2_title) {                                // 14
            $('#tab2_title').html(publicSetting.tab2_title);           // 15
        }                                                              //
        if (publicSetting.date_head) {                                 // 17
            $('#date_head').html(publicSetting.date_head);             // 18
        }                                                              //
        if (publicSetting.category_head) {                             // 20
            $('#category_head').html(publicSetting.category_head);     // 21
        }                                                              //
        if (publicSetting.infoType_head) {                             // 23
            $("#infoType_head").html(publicSetting.infoType_head);     // 24
        }                                                              //
        if (publicSetting.name_head) {                                 // 26
            $("#name_head").html(publicSetting.name_head);             // 27
        }                                                              //
        if (publicSetting.subName_head) {                              // 29
            $("#subName_head").html(publicSetting.subName_head);       // 30
        }                                                              //
        if (publicSetting.description_head) {                          // 32
            $("#description_head").html(publicSetting.description_head);
        }                                                              //
        if (publicSetting.chat_head) {                                 // 35
            $("#chat_head").html(publicSetting.chat_head);             // 36
        }                                                              //
    });                                                                //
    Template.body.helpers({                                            // 39
        logs: function () {                                            // 40
            var log = Logs.find({}, { sort: { date: -1 } }).fetch().filter(function (x, i, arr) {
                return arr.indexOf(arr.find(function (y, j, arr2) {    // 42
                    return y.name === x.name && y.sub_name === x.sub_name;
                })) == i;                                              //
            });                                                        //
            if (Session.get("selected_infoType_filter")) {             // 46
                log = log.filter(function (x, i, arr) {                // 47
                    return x.info_type === Session.get("selected_infoType_filter");
                });                                                    //
            }                                                          //
                                                                       //
            return log.map(function (l) {                              // 52
                return {                                               // 53
                    log_id: l._id,                                     // 54
                    date: l.date.toFormat('YYYY/MM/DD HH24:MI:SS'),    // 55
                    info_type: l.info_type,                            // 56
                    category: l.category,                              // 57
                    name: l.name,                                      // 58
                    sub_name: l.sub_name,                              // 59
                    description: l.description                         // 60
                };                                                     //
            });                                                        //
        },                                                             //
        comments: function () {                                        // 64
            if (Session.get("selected_log_id")) {                      // 65
                var comment = Comments.find({ "log_id": Session.get("selected_log_id") }).fetch();
                return comment.map(function (c) {                      // 67
                    return { date: c.date.toFormat('YYYY/MM/DD HH24:MI:SS'), name: c.name, text: c.text };
                });                                                    //
            }                                                          //
        }                                                              //
    });                                                                //
    Template.body.events = {                                           // 73
        'change select#ddlInfoTypeFilter': function (e) {              // 74
            Session.set("selected_infoType_filter", $(e.currentTarget).val());
            Tracker.flush();                                           // 76
        },                                                             //
        'click #btn-export': function (e) {                            // 78
            window.open('/get/log/summary', 'download');               // 79
        }                                                              //
    };                                                                 //
                                                                       //
    Template.log.events = {                                            // 83
        'click button.chat-start': function (e) {                      // 84
            Session.set("selected_log_id", $(e.currentTarget).attr('log-id'));
            $('#chat-area')[0].style.display = '';                     // 86
            $("button.chat-start").removeClass("btn-warning");         // 87
            $("button.chat-start").addClass("btn-default");            // 88
            $(e.currentTarget).addClass('btn-warning');                // 89
            Tracker.flush();                                           // 90
        }                                                              //
    };                                                                 //
                                                                       //
    Template.chat_input.events = {                                     // 94
        'click button#submit': function (evt) {                        // 95
            var name = $("#name").val();                               // 96
            var text = $("#text").val();                               // 97
                                                                       //
            if (name == "" || text == "") return;                      // 99
            if (Session.get("selected_log_id")) {                      // 100
                                                                       //
                Comments.insert({ log_id: Session.get("selected_log_id"), name: name, text: text, date: new Date() });
                $("#text").val("");                                    // 103
                $("#text").focus();                                    // 104
            }                                                          //
        }                                                              //
    };                                                                 //
}                                                                      //
                                                                       //
if (Meteor.isServer) {                                                 // 111
    var queryString = Meteor.npmRequire('querystring');                // 112
    var fs = Meteor.npmRequire('fs');                                  // 113
    Meteor.startup(function () {});                                    // 114
                                                                       //
    Picker.route('/post/log/', function (params, req, res, next) {     // 117
        var data = '';                                                 // 118
        req.on('data', function (chunk) {                              // 119
            data += chunk;                                             // 120
        });                                                            //
                                                                       //
        req.on('end', Meteor.bindEnvironment(function (error, body) {  // 123
            if (req.method === 'POST') {                               // 124
                var json = JSON.parse(queryString.parse(data).result);
                console.log(json);                                     // 126
                Logs.insert({                                          // 127
                    date: new Date(),                                  // 128
                    info_type: json.info_type,                         // 129
                    category: json.category,                           // 130
                    name: json.name,                                   // 131
                    sub_name: json.sub_name,                           // 132
                    description: json.description                      // 133
                });                                                    //
                res.end("ok");                                         // 135
            } else {                                                   //
                res.end('ng');                                         // 138
            }                                                          //
        }));                                                           //
    });                                                                //
    Picker.route('/get/log/summary/', function (params, req, res, next) {
        var textdata = "write text test!";                             // 143
                                                                       //
        var download = Meteor.bindEnvironment(function () {            // 146
            var log = Logs.find({}, { sort: { date: -1 } }).fetch().filter(function (x, i, arr) {
                return arr.indexOf(arr.find(function (y, j, arr2) {    // 149
                    return y.name === x.name && y.sub_name === x.sub_name;
                })) == i;                                              //
            });                                                        //
            var loglist = log.map(function (l) {                       // 153
                return {                                               // 154
                    log_id: l._id,                                     // 155
                    date: l.date.toFormat('YYYY/MM/DD HH24:MI:SS'),    // 156
                    info_type: l.info_type == 'complete' ? '○' : l.info_type,
                    category: l.category,                              // 158
                    name: l.name,                                      // 159
                    sub_name: l.sub_name,                              // 160
                    description: l.description                         // 161
                };                                                     //
            });                                                        //
            //start                                                    //
            textdata += "\n\n★実行中";                                    // 165
            for (var _iterator = loglist.filter(function (a) {         // 166
                return a.info_type == 'start';                         //
            }), _isArray = Array.isArray(_iterator), _i = 0, _iterator = _isArray ? _iterator : _iterator[Symbol.iterator]();;) {
                var _ref;                                              //
                                                                       //
                if (_isArray) {                                        //
                    if (_i >= _iterator.length) break;                 //
                    _ref = _iterator[_i++];                            //
                } else {                                               //
                    _i = _iterator.next();                             //
                    if (_i.done) break;                                //
                    _ref = _i.value;                                   //
                }                                                      //
                                                                       //
                var l = _ref;                                          //
                                                                       //
                textdata += "\n" + l.name + "\n=> " + l.description;   // 167
            }                                                          //
            //error                                                    //
            textdata += "\n\n\n★エラー";                                  // 170
            for (var _iterator2 = loglist.filter(function (a) {        // 171
                return a.info_type == 'error';                         //
            }), _isArray2 = Array.isArray(_iterator2), _i2 = 0, _iterator2 = _isArray2 ? _iterator2 : _iterator2[Symbol.iterator]();;) {
                var _ref2;                                             //
                                                                       //
                if (_isArray2) {                                       //
                    if (_i2 >= _iterator2.length) break;               //
                    _ref2 = _iterator2[_i2++];                         //
                } else {                                               //
                    _i2 = _iterator2.next();                           //
                    if (_i2.done) break;                               //
                    _ref2 = _i2.value;                                 //
                }                                                      //
                                                                       //
                var l = _ref2;                                         //
                                                                       //
                textdata += "\n" + l.name + "\n=> " + l.description;   // 172
            }                                                          //
            //全体                                                       //
            textdata += "\n\n\n★全体の状況";                                // 175
                                                                       //
            for (var _iterator3 = loglist, _isArray3 = Array.isArray(_iterator3), _i3 = 0, _iterator3 = _isArray3 ? _iterator3 : _iterator3[Symbol.iterator]();;) {
                var _ref3;                                             //
                                                                       //
                if (_isArray3) {                                       //
                    if (_i3 >= _iterator3.length) break;               //
                    _ref3 = _iterator3[_i3++];                         //
                } else {                                               //
                    _i3 = _iterator3.next();                           //
                    if (_i3.done) break;                               //
                    _ref3 = _i3.value;                                 //
                }                                                      //
                                                                       //
                var l = _ref3;                                         //
                                                                       //
                textdata += "\n" + l.name + "\t" + l.info_type + "\t" + l.description;
            }                                                          //
                                                                       //
            fs.writeFile(Meteor.rootPath + '\\temp\\writetest.txt', textdata, function (err) {
                if (err) {                                             // 182
                    console.log('writefile happens error :' + err);    // 182
                }                                                      //
                fs.readFile(Meteor.rootPath + '\\temp\\writetest.txt', function (err, data) {
                    if (err) {                                         // 184
                        console.log('readfile happens error :' + err);
                    }                                                  //
                    res.writeHead(200, {                               // 185
                        'Content-Type': 'application/octet-stream',    // 187
                        'Content-Disposition': 'attachment; filename=hogehoge.txt'
                    });                                                //
                    res.write(data);                                   // 190
                    res.end();                                         // 191
                });                                                    //
            });                                                        //
        });                                                            //
                                                                       //
        if (!fs.exists(Meteor.rootPath + '\\temp')) {                  // 197
            fs.mkdir(Meteor.rootPath + '\\temp', function (e) {        // 198
                if (e) {                                               // 199
                    console.log('mkdir happens error :' + e);          // 199
                }                                                      //
                download();                                            // 200
            });                                                        //
        } else {                                                       //
            download();                                                // 203
        }                                                              //
    });                                                                //
}                                                                      //
/////////////////////////////////////////////////////////////////////////

}).call(this);

//# sourceMappingURL=import_log_summary.js.map
