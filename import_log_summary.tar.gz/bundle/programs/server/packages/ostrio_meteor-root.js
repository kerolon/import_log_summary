(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;

(function(){

/////////////////////////////////////////////////////////////////////////////
//                                                                         //
// packages/ostrio_meteor-root/meteor-root.js                              //
//                                                                         //
/////////////////////////////////////////////////////////////////////////////
                                                                           //
Meteor.rootPath     = __meteor_bootstrap__.serverDir;                      // 1
Meteor.absolutePath = __meteor_bootstrap__.serverDir.split('/.meteor')[0];
/////////////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['ostrio:meteor-root'] = {};

})();

//# sourceMappingURL=ostrio_meteor-root.js.map
